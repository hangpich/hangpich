🧨 Tool នេះអាចប្រើសម្រាប់បញ្ចូន request ច្រើនក្នុងពេលតែមួយ។

----------------------
🔧 How to Use / របៀបប្រើ:
----------------------

1. 📦 ត្រូវដំឡើងឯកសារ ZIP (Extract the zip file)
2. 📂 បើក Terminal រួចចូលទៅក្នុង folder:
   cd ~/Downloads/DDOSSIEM
3. 🛠 ប្តូរឲ្យ file អាចដំណើរការ:
   chmod +x ddossiembin
4. 🚀 ចាប់ផ្តើមរត់ tool:
   ./ddossiembin

Tool UI៖
- 🌐 Target URL (https://example.com)
- 📥 Method: GET / POST / HEAD / ALL
- 🔁 Threads (ចំនួន thread ដំណើរការតែមួយ)
- ⏱ Duration (ចំនួនវិនាទី)
- ❓ Use proxy? ចូល y ប្រសិនបើមាន proxies.txt

----------------------------
🌐 Proxy (Optional / ជាជម្រើស):
----------------------------

 proxy:
- បង្កើតឯកសារ proxies.txt នៅក្នុង folder
- បញ្ចូល IP:PORT នៅក្នុងមួយបន្ទាត់
  ឧ.:
    103.172.70.52:4145
    51.222.253.4:3128

Tool នឹងប្រើ proxy មួយដោយចៃដន្យសម្រាប់ request នីមួយៗ។

-----------------------------
📁 Output / លទ្ធផលបង្ហាញ:
-----------------------------

- Tool នឹងបង្ហាញចំនួន Success ✅ និង Failed ❌
- បន្ទាប់ពីបញ្ចប់, វានឹងសរសេរទៅ result.log

-----------------------------
✅ Recommendation:
-----------------------------

- ✅ ប្រើលើ Kali Linux / Debian OS / not on Windows 
- ✅ អាចដំណើរការ ដោយមិនចាំបាច់ install Python
- ✅ ប្រើ VPN ឬ VPS ដើម្បីបង្កើនសុវត្ថិភាព
- ✅ ប្រើ rotating proxies ដើម្បីបង្កើនការបែងចែក request

-----------------------------
⚠️ Legal Warning / ការព្រមានច្បាប់: ប្រើដោយការទទួលខុសត្រូវ
-----------------------------

